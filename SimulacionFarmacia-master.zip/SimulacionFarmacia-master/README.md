# SimulacionFarmacia
Este es un codigo de simulacion de una farmacia utilizando base de datos, como parte de un proyecto escolar, en lenguaje JAVA desde el desarrollador ECLIPSE.
